# 公共契约（T002 / T101）

本包只依赖 Zod 4.6.7，Schema 同时生成运行时校验与 TypeScript 类型。不依赖 NestJS、Fastify、数据库、队列或 Node 专用模块。

| 导入入口                             | 内容                                                                                                   |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------ |
| `@agentscope/contracts` 或 `/common` | 公共值、领域状态和错误                                                                                 |
| `@agentscope/contracts/management`   | 公共值及单资源/列表响应工厂、分页信息                                                                  |
| `@agentscope/contracts/ingestion`    | SDK 需要的 ID、UTC 时间、Trace 状态、ContentValue、内容策略、事件 v1 和批次；不导出管理响应或 Run 状态 |

采用 PascalCase + Schema 后缀，类型通过 `z.infer` 推导。边界只校验，不隐式转型或改写：HTTP 字段为 snake_case；未知值由调用方显式使用 nullable/optional，不能将未知费用变成零。

- UUID 使用标准 UUID 校验；Trace/Span ID 分别是 32/16 位非全零小写十六进制。
- UTC 时间必须含秒并以 `Z` 结尾，允许小数秒，不接受本地时间或偏移时区；耗时是有限非负毫秒数。
- revision 是 0 到 JS 最大安全整数之间的整数；`ExpectedRevisionSchema` 定义 `{expected_revision}`，具体资源初值和递增事务由对应服务实现。
- 金额为非负十进制字符串，最多 12 位整数和 12 位小数，对应 numeric(24,12)；保留尾随零，不接受指数、前导零或浮点数。currency 仅校验三位大写形式，实际可用币种由模型/价格配置约束，不宣称已验证所有 ISO 币种。
- 计数使用非负安全整数；超过 JS 安全范围时使用无前导零的十进制字符串，上限是 PostgreSQL signed bigint 最大值。Schema 不负责数据库 bigint 的序列化转换。
- Trace 的 success/error 与 Run 的 succeeded/failed 保持不同枚举；状态 Schema 只验证成员，不承担状态迁移规则。
- 资源/列表/错误 envelope 使用严格对象校验，禁止把额外字段静默剥离。业务返回额外 meta 时应显式扩展响应 Schema。`has_more=true` 必须带非空 next_cursor，结束页为 false/null。
- 错误 details 仅接收 JSON 对象。Schema 不能识别其中的秘密，生产者仍须仅输出安全字段路径、索引、原因和公开元数据；T003 已接入 API 异常处理链。

T003 已在 management 入口加入 LoginRequest、SessionData 与 SessionResponse Schema；会话响应仅返回 user.id/username、csrf_token 和 expires_at。T004 已加入项目创建/更新/列表 query/响应 Schema，M0 settings 固定为 {}，名称与描述有长度上限，更新要求 expected_revision；T101 已固化 ContentValue 与事件 v1；评测及运行请求仍在后续阶段固化。Q001 已确认双开关策略，T102 已实现服务端管理和接收，T105 已接通 SDK，T107 后续承接界面。

`fixtures/public-imports.ts` 从公开 exports 导入，分别在无 Node 类型的浏览器 Bundler 和 NodeNext 环境检查。SDK 的独立 fixture 只引用 ingestion；最小打包测试验证入口可解析且无服务端依赖。测试预先构建 contracts，类型检查预先构建共享包，不要求手动保留 dist。

Schema API 依据：[Zod 官方文档](https://zod.dev/api)。

## 采集事件 v1（T101）

`IngestionEventSchema` 是 span.started / span.ended 严格判别联合；`IngestionBatchSchema` 接收 `{events}`（1–100 项）。不接受项目 ID、任意 patch 或未知字段。根开始要求 environment/sample_rate，父不能为自己；结束只允许 success/error/canceled。UTC 时间最多三位小数秒，occurred_at 与 payload 对应时间相等。动态接收年龄/时钟窗口、鉴权、内容策略执行、去重和跨事件关系属于后续服务，Schema 不会凭固定 fixture 假定当前时钟。

ContentValue 的 disabled/unavailable 只含 status；captured/redacted/truncated 必须有 value，可为真实 JSON null。截断状态与 truncated 标志必须一致，redacted_paths 可记录混合脱敏状态。单 value 和 attributes/parameters 对象各限 32 KiB，单事件 256 KiB，批次 1 MiB，按 JSON 编码后的 UTF-8 字节计算；请求原始字节上限在 T102 入口另行执行。JSON 最大深度 32，拒绝循环、非有限数、BigInt、undefined、非普通对象、NUL 与孤立代理字符，兼容浏览器与 PG jsonb。

ContentPolicySchema 的 capture_content 缺省 false，SDK 默认 false；两者同时允许才保存正文。此契约不执行脱敏，也不代表设置接口或采集接口已经开放。固定时钟样本位于 `src/ingestion/fixtures.ts`，供测试复用，不从公共入口自动打包进入业务应用。

## T102 管理与确认契约

management 入口新增 CreateIngestionKey/IngestionKey/CreatedIngestionKey、ProjectContentSettings/UpdateProjectContentSettings Schema。创建密钥响应单独包含 secret，普通元数据 Schema 不允许该字段；设置 PATCH 要求 revision 和显式 boolean。Project.settings 从 {} 扩展为可选 content_policy，兼容已有项目。ingestion 入口新增 IngestionReceiptSchema（accepted + duplicates 为 1–100），仍不导出管理契约或服务端依赖。

## T103 恢复契约

management 入口新增 IngestionFailure / IngestionAttempt、RecoveryPageQuery 和 RequeueIngestionEvent Schema。失败只暴露标识、状态、固定错误码与计数，不暴露 payload。重派严格要求 expected_attempt_count，拒绝额外正文/覆盖字段；失败和尝试分页默认 20、上限 100，游标限 1024 字符并绑定项目/事件。ingestion 与 common 入口仍不引入 Worker、BullMQ 或数据库依赖。

## T104/T105 SDK 消费边界

SDK 生命周期仅消费 ingestion 入口，生成事件前校验 v1 Schema，再交给有界 HTTP 出口或显式 exporter。新增 SDK 公共 ESM/声明 fixture、运行入口与打包依赖验证；未引入管理、服务端数据库或 Worker 模块。T105 按 IngestionReceiptSchema 校验 202，且 accepted+duplicates 必须等于批次数量才释放预算；显式 exporter 模式只确认本地交付。

## T106 管理查询契约

management 入口新增 Trace/Span 查询、有效筛选、摘要/详情/分页响应及用量/费用/内容覆盖率 Schema；ingestion/SDK 入口不引入管理依赖。M1 严格接受时间与状态筛选，未来 M2 字段暂不接受。Count 保留 bigint 精度，金额仍为 decimal string，未知值和真实 JSON null 分开；浏览器/Node fixture 包含新查询类型。具体结构与分页口径见 docs/api.md 的 T106 小节。
