# Node SDK（T104/T105）

私有工作区包，支持 Node.js 22.17.0 ESM、该版本原生 require(ESM) 互操作入口与 TypeScript 声明。只依赖轻量 ingestion 契约及 Node 内置模块，不包含数据库、管理接口、Worker 或模型客户端。

```typescript
import { AgentScope } from '@agentscope/sdk';

const scope = new AgentScope({
  endpoint: 'http://localhost:3000', // 服务根地址；SDK POST /api/v1/ingest
  apiKey: process.env.AGENTSCOPE_API_KEY!,
  environment: 'development',
  captureContent: false,
});

try {
  const result = await scope.trace('agent', async (trace) => {
    await trace.span('tool', { kind: 'tool' }, () => 42);
    return trace.generation('answer', (generation) => {
      generation.setModel({ provider: 'fixture', model: 'offline' });
      generation.setUsage({ inputTokens: 4, outputTokens: 2 });
      generation.setOutput('answer');
      return 'answer';
    });
  });
  console.log(result);
  console.log(await scope.flush({ timeoutMs: 2000 }));
} finally {
  await scope.shutdown({ timeoutMs: 2000 });
}
```

业务回调由应用执行，SDK 保持结果引用与原异常对象；SDK 错误只产生安全诊断。构造阶段非法配置会以字段名报错，不包含配置值或原错误。endpoint 必须是 http/https 根地址，不允许用户信息、路径、查询或 fragment；重定向被拒绝，避免向其他地址转发密钥。SDK 不进行启动网络探测。

## 内容和生命周期

正文默认 disabled，只有 SDK captureContent 和项目开关均开启，服务端才保留正文。input 在创建时快照；output 必须显式 setOutput，不采集回调返回值。input/output/messages/error 正文共用开关；attributes 始终过滤敏感键和正文旁路字段，模型 parameters 仅数值白名单。未知 Token 保持未知，setUsage 替换整份快照，不补零；setModel 合并指定字段。

正文先安全复制、过滤敏感键，再经过可选 `redactor(value)`，最后再次过滤和校验。文本脱敏在截断前执行；无法在遍历预算内安全复制的结构先替换为摘要，再交给 redactor。metadata 也执行 redactor 和二次过滤，不能绕过正文策略。自定义 getter/toJSON、循环、BigInt 等非法 JSON 降级 unavailable，脱敏异常不退回原文。32 KiB 为默认正文上限，文本按 JSON UTF-8 字节保留完整字符前缀；结构超限保存摘要，状态 truncated。遍历预算为 4096 节点/24 层，脱敏路径最多 100 条/4 KiB。自然语言秘密、名称和标签仍需调用方选择。

`trace/span/generation` 回调在 Promise 完成时自动 end。手动 `startSpan` 不切换上下文；用 `withSpan` 在回调范围内绑定，并自行 end。withSpan 原样返回同步结果或同一个 Promise，不自动结束。end 幂等；recordError 固定自身 error 终态；迟到、未采样及关闭后的回调仍执行，但不产生新事件。每个 scope 独立隔离异步上下文，建议应用级复用并显式 shutdown。

## 配置、队列和重试

| 配置                           | 默认值         | 限制                                 |
| ------------------------------ | -------------- | ------------------------------------ |
| sampleRate                     | 1              | 0–1；根 Trace 一次决定，子步骤继承   |
| flushIntervalMs                | 1000           | 正整数毫秒                           |
| maxBatchEvents                 | 100            | 1–100                                |
| maxRequestBytes                | 1048576        | 1–1 MiB，含完整 JSON 包装            |
| maxEventBytes                  | 262144         | 1–256 KiB                            |
| maxContentBytes                | 32768          | 64–32 KiB，按 JSON 编码值计量        |
| maxQueueEvents / maxQueueBytes | 1000 / 8388608 | 正整数，同时限制等待、重试及在途事件 |
| requestTimeoutMs               | 5000           | 正整数，含响应体读取                 |
| maxRetryAgeMs                  | 86400000       | 1 毫秒–24 小时，使用单调时钟         |

其他整数上限为 2147483647。队列按已序列化事件字节计量，不是整个 Node 堆的硬上限；超限丢弃新事件，不阻塞业务。发送循环串行，批次同时遵守数量和字节限制；202 收据必须合法且 accepted+duplicates 等于批次长度，才能释放预算。这表示已接收，不表示 Worker 已投影。

网络错误、429、500/502/503/504 退避重试并遵守 Retry-After；事件 ID、时间与正文不变。413 拆批，单事件仍失败则丢弃。400/409 的 error.details.index 合法时只丢该项，否则丢整批。401/403 暂停网络；后续数据仍受队列预算和年龄限制，需创建配置有效的新 scope。没有磁盘缓冲，崩溃或强制退出会丢失未确认事件。

T104 的可选 `exporter(event)` 入口保留：显式提供后替代 HTTP，无需 endpoint/apiKey，立即接收深冻结事件。异步 exporter 同样计入有界在途预算，flush/shutdown 会等待它；此模式 accepted 仅表示 exporter 调用成功，不表示服务端接收，SDK 不替它重试。exporter 应轻量，应用自行管理其外部资源。exporter、HTTP、redactor 和诊断的异步工作均抑制 SDK 自身埋点。

## 流观察

使用手动 LLM 句柄，不要通过返回 iterable 提前结束 generation 回调：

```typescript
await scope.trace('streaming-agent', async (trace) => {
  const span = trace.startSpan('answer', { kind: 'llm' });
  async function* source() {
    yield { text: 'hello' };
    yield { text: ' world', usage: { outputTokens: 2 } };
  }
  const observed = scope.observeStream(span, source(), {
    text: (chunk) => chunk.text, // 心跳返回 undefined 或空串
    usage: (chunk) => chunk.usage, // 完整归一化快照；未知则省略
    // signal: controller.signal,
  });
  for await (const chunk of observed) console.log(chunk.text);
});
```

不预取或重复消费，chunk 引用和顺序保持不变；首个非空文本使用 Span 开始后的单调时间计算 TTFT。正文受限缓冲，达到上限继续向业务传递 chunk，但停止追加采集正文，最终标 truncated；正文关闭时仍可记录 TTFT 和用量。没有内容时 output 保持 unavailable/disabled，未知 usage 不补零。

正常完成 success；break/return 转发上游 return 并 canceled；上游异常记录 error 并抛同一对象。代理也转发 iterator.throw。AbortSignal 只标记采集 canceled，不代替业务向模型发起取消，须把同一 signal 传给上游客户端；原取消异常继续透传。竞争结束只发一次终态。未消费的流不自动拉取，需手动 end；shutdown 不伪造结束事件，平台可显示未完成/stale。

## flush、shutdown 与诊断

flush 只等待调用时仍在队列中的事件；后来事件不会延长屏障，已确认/已丢弃的历史不计入本次结果。返回 `{accepted, duplicates, dropped, pending, timedOut}`，网络失败不会抛出。应先 await 业务回调，再 flush，才能涵盖其结束事件。

shutdown 多次调用返回同一个 Promise，停止新采集和周期发送，执行有限时 flush，取消剩余请求、释放剩余队列与流监听器；业务回调继续。超时结果保留截止时的 pending，随后这些事件按 SHUTDOWN 丢弃并计入诊断。异步上下文在活跃的 SDK 业务回调结束后释放；未 await 的后台工作不延长关闭。SDK 使用应用的原生 fetch，没有独立连接池；不关闭应用共享连接。不要在同步 process exit 中假装等待上报。

getDiagnostics 返回冻结快照：queued、in_flight、queue_bytes、accepted、duplicates、retry_count、last_error_code、dropped_by_reason，以及兼容的 eventsEmitted/exportFailed/byCode。eventsEmitted 是有效事件交给出口的次数；丢弃原因区分 QUEUE_FULL、EVENT_TOO_LARGE、EVENT_REJECTED、HTTP_REJECTED、RETRY_EXPIRED、EXPORT_FAILED、SHUTDOWN。诊断不包含正文、密钥、原网络错误或响应体；回调每种代码每秒最多一次，计数仍全部保留。

## 验证

从仓库根目录运行 `pnpm test:unit`、`pnpm typecheck`、`pnpm lint`、`pnpm format:check`、`pnpm build` 和 `pnpm --filter @agentscope/sdk test:entry`。

T105 使用虚拟时间、mock fetch/exporter、公共编译 ESM 入口及声明 fixture 验证；不调用真实模型、PG、Redis 或外部网络。覆盖采样继承、双预算、稳定重试、收据、拆批/坏项、限流/鉴权/年龄、flush 屏障/关闭/资源清理、递归隔离、内容脱敏截断、流完成/取消/异常/竞争和依赖边界。GUI/E2E、真实模型与压测未执行。实现进度和实际检查结果见 [任务清单](../../tasks/todo.md)。

## 其他仓库与 CommonJS 接入

Node 22.17.0 的 CommonJS 消费者可使用 `const { AgentScope } = require('@agentscope/sdk')`。require/import 指向同一份无顶层 await 的 ESM，实现不复制异步上下文；这不是对旧 Node 或任意打包器的 CJS 兼容承诺。类型入口同时通过 main/types 提供给 Gist 的传统 TypeScript CommonJS 解析器。

当前仍为私有包，SDK 运行时依赖 contracts；跨仓库安装需同时提供两份构建产物，不能只复制 SDK 的 dist。已验证的本地归档安装方式见 [Gist 接入记录](../../docs/integrations/gist-agent.md)。

结构化流式输出可通过 `StreamAdapter.output()` 返回 `{ value, truncated? }`，用于工具调用等非文本结果。适配器须有界缓冲；SDK 在完成、异常或取消时调用一次，并继续执行正文脱敏与大小限制。不开启正文时不调用 output；原 chunk 引用、异常与迭代器取消语义保持不变。
